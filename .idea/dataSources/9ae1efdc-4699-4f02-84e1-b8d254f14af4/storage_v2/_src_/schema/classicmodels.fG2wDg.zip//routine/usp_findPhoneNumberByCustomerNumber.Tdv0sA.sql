create
    definer = root@localhost procedure usp_findPhoneNumberByCustomerNumber(IN number int, OUT phoneNumber varchar(50))
begin
    select phone into phoneNumber from customers where customerNumber=number;
end;

