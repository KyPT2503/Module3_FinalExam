create
    definer = root@localhost procedure usp_findCustomerNameByCustomerNumber(IN number int)
begin
    select customerName from customers where customerNumber=number;
end;

