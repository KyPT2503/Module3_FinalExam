create
    definer = root@localhost procedure usp_findCustomerNumberByContactFirstName(IN name varchar(50))
begin
    select * from customers where customerName = name;
end;

