create
    definer = root@localhost procedure usp_countNumberOfPerson(INOUT count int)
begin
    set count =count+(select count(*) from customers);
end;

