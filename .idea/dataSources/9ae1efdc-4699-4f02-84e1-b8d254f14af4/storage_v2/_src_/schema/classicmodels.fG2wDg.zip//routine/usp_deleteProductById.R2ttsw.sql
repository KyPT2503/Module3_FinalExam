create
    definer = root@localhost procedure usp_deleteProductById(IN code_ int)
begin
    delete from product where code=code_;
end;

