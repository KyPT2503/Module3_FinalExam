create
    definer = root@localhost procedure usp_editProductById(IN code_ int, IN newName varchar(255), IN newPrice int,
                                                           IN newAmount int, OUT money int)
begin
    call usp_deleteProductById(code_);
    call usp_insertNewProduct(code_,newName,newPrice,newAmount);
    set money=newPrice*newAmount;
end;

