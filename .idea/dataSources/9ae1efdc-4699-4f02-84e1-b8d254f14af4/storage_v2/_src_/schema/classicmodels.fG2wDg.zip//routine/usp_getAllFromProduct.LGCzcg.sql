create
    definer = root@localhost procedure usp_getAllFromProduct()
begin
    select * from product;
end;

