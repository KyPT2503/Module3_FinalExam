create
    definer = root@localhost procedure usp_insertNewProduct(IN code_ varchar(32), IN name_ varchar(255), IN price_ int,
                                                            IN amount_ int)
begin
    insert into product (code, name, price, amount) value (code_,name_,price_,amount_);
end;

