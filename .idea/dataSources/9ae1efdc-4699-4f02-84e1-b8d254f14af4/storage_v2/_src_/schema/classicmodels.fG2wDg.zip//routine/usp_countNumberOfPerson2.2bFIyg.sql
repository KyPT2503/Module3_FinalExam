create
    definer = root@localhost procedure usp_countNumberOfPerson2(INOUT count int)
begin
    set count =count+(select count(*) from customers);
end;

